// Переменная текущего активного ключа (обновляется при выборе сервера)
let activeVpnUrl = "vless://DE_SERVER_LINK";

let logicInterval, timerInterval, graphInterval;
let seconds = 0, minutes = 0, hours = 0;
let totalTraffic = 0;

// Инициализация холста для живого графика трафика
const canvas = document.getElementById('trafficGraph');
const ctx = canvas.getContext('2d');
let points = new Array(30).fill(25); // Базовая прямая линия

function drawGraph() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.lineWidth = 2;
    // Меняем цвет неоновой линии графика в зависимости от статуса VPN
    ctx.strokeStyle = document.body.classList.contains('connected') ? '#10b981' : '#a855f7';
    ctx.beginPath();
    
    const sliceWidth = canvas.width / (points.length - 1);
    for (let i = 0; i < points.length; i++) {
        const x = i * sliceWidth;
        const y = points[i];
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.stroke();
}

// Изменение размеров холста под экран
function resizeCanvas() {
    canvas.width = canvas.parentElement.clientWidth;
    canvas.height = canvas.parentElement.clientHeight;
    drawGraph();
}
window.addEventListener('resize', resizeCanvas);
setTimeout(resizeCanvas, 100);

function toggleVpn() {
    const body = document.body;
    const stateLabel = document.getElementById('statusState');
    const btnText = document.getElementById('btnText');
    const cipher = document.getElementById('cipherVal');

    if (body.classList.contains('connected')) {
        // ВЫКЛЮЧЕНИЕ
        body.classList.remove('connected');
        stateLabel.innerText = 'Отключена';
        btnText.innerText = 'Старт';
        cipher.innerText = 'AES-256';
        
        clearInterval(logicInterval);
        clearInterval(timerInterval);
        clearInterval(graphInterval);
        
        document.getElementById('downSpeed').innerText = '0.0 Мб/с';
        document.getElementById('upSpeed').innerText = '0.0 Мб/с';
        
        // Возвращаем график в плоское состояние
        points.fill(canvas.height / 2);
        drawGraph();

        if (window.AndroidVPN) window.AndroidVPN.stopTunnel();
    } else {
        // ВКЛЮЧЕНИЕ
        body.classList.add('connected');
        stateLabel.innerText = 'Активна';
        btnText.innerText = 'Стоп';
        cipher.innerText = 'CHACHA20';
        
        seconds = 0; minutes = 0; hours = 0;
        totalTraffic = 0;
        runTimer();
        runLiveStats();
        runGraphAnimation();

        if (window.AndroidVPN) window.AndroidVPN.startTunnel(activeVpnUrl);
    }
}

function runLiveStats() {
    logicInterval = setInterval(() => {
        const downNum = Math.random() * (62 - 18) + 18;
        const upNum = Math.random() * (16 - 3) + 3;
        
        document.getElementById('downSpeed').innerText = downNum.toFixed(1) + ' Мб/с';
        document.getElementById('upSpeed').innerText = upNum.toFixed(1) + ' Мб/с';
        
        totalTraffic += (downNum + upNum) / 8 * 1.5;
        document.getElementById('trafficVal').innerText = totalTraffic.toFixed(2) + ' МБ';
    }, 1500);
}

function runGraphAnimation() {
    graphInterval = setInterval(() => {
        // Добавляем случайную кардиограмму в массив точек графика
        points.shift();
        const nextY = Math.random() * (canvas.height - 5) + 5;
        points.push(nextY);
        drawGraph();
    }, 300);
}

function runTimer() {
    timerInterval = setInterval(() => {
        seconds++;
        if (seconds >= 60) { seconds = 0; minutes++; }
        if (minutes >= 60) { minutes = 0; hours++; }
        const h = hours < 10 ? '0' + hours : hours;
        const m = minutes < 10 ? '0' + minutes : minutes;
        const s = seconds < 10 ? '0' + seconds : seconds;
        document.getElementById('timerVal').innerText = h + ':' + m + ':' + s;
    }, 1000);
}

// Функции управления выезжающей шторкой выбора серверов
function openServerList() {
    document.getElementById('serverSheet').classList.add('open');
    document.getElementById('sheetOverlay').classList.add('open');
}

function closeServerList() {
    document.getElementById('serverSheet').classList.remove('open');
    document.getElementById('sheetOverlay').classList.remove('open');
}

function selectServer(flag, title, ping, url) {
    document.getElementById('currentFlag').innerText = flag;
    document.getElementById('currentTitle').innerText = title;
    document.getElementById('currentPing').innerText = ping;
    activeVpnUrl = url; // Заменяем активный ключ
    closeServerList();
}

function openSupport() {
    alert("Техподдержка Aspect VPN: напишите нам в Telegram @AspectVPN_Support");
}
